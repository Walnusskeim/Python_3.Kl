# Blackjack
2D Blackjack with Customtkinter and PIL 

Comments and a better design will be added soon.

17.06.2023 Comments and better design added
